import {ACTIONS_ISLOGGED} from '.'
const logOut = () => {
	return {type: ACTIONS_ISLOGGED.OUT}
}

export default logOut;