import {ACTIONS_MENSAJES} from '../actions'
const vaciarMensajes = () => {
	return {type: ACTIONS_MENSAJES.VACIAR}
}
export default vaciarMensajes;