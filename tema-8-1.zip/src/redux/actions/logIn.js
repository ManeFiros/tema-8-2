import {ACTIONS_ISLOGGED} from '../actions'
const logIn = () => {
	return {type: ACTIONS_ISLOGGED.IN}
}

export default logIn;