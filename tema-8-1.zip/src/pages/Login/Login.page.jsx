import './Login.page.css'
import { useState } from 'react';
import * as Yup from 'yup';
import { useSelector, useDispatch } from 'react-redux';
import { borrarMensaje, crearMensaje, leerMsj, vaciarMensajes } from '../../redux/actions';
import { Link } from 'react-router-dom';
import { logOut, logIn } from '../../redux/actions';

export default function Login(props) {
    const isLogged = useSelector(state => state.isLogged);
    const dispatch = useDispatch();
    const [showModal,setShowModal] = useState(false);

    const setLogOut = () =>{ dispatch(logOut())}

    let controlLoggin = () => {
        return{
          pathname: '/mensajes',
          state:{
            isLogged: true
          }
        }
      }

    let nuevoMensaje = (values, {setSubmitting}) => {
        //e.preventDefault();
        setShow();
        let nuevo = {
            "asunto":  `${values.nombre}`,//e.target.getElementsByTagName("input")[0].value,
            "email":   `${values.mail}`,//e.target.getElementsByTagName("input")[1].value,
            "mensaje": `${values.descripcion}`,//e.target.getElementsByTagName("textarea")[0].value,
            "leido":false
        };
        
        dispatch(crearMensaje(nuevo));
        setSubmitting(false);
    };

    let eliminarMensajes = () => { dispatch(vaciarMensajes()); };
      
    let eliminarMensaje = (index) => { dispatch(borrarMensaje(index)); };
    
    let leerMensaje = (index) => { dispatch(leerMsj(index)); };

    let setShow = () => { setShowModal(!showModal); };

    const validaciones = Yup.object().shape({
        nombre: Yup.string()
          .required('Por favor, escribe el asunto.'),
        descripcion: Yup.string()
          .required('Por favor, escribe un mensaje.')
          .min(10, 'Mínimo 10 carácteres.'),
        mail: Yup.string()
          .required("Por favor, incluye el e-mail")
          .email("Introduzca un e-mail válido")
    });
    
    return (
        <div className="Login">
           
                { isLogged ?
                <button onClick={setLogOut}>
                            Cerrar sesión
                </button>:
                <form>
                    <Link to={controlLoggin()}><button className="Nuevo">Iniciar sesión</button></Link>
                
                </form>
                }
        </div>
    );
}