import logo from './logo.svg';
import './App.css';
import React from 'react';
import {BrowserRouter as Router, Redirect, Route, useHistory} from 'react-router-dom';
import Mensajes from './pages/Mensajes/Mensajes.page';
import Login from './pages/Login/Login.page';
import {ProtectedRoute} from './components/ProtectedRoute/ProtectedRoute.component';
import { useSelector, useDispatch } from 'react-redux';
import { logOut, logIn } from './redux/actions';

function App(props) {
  const isLogged = useSelector(state => state.isLogged);
  const dispatch = useDispatch();

  let controlLoggin = () => {
    if(isLogged) dispatch(logOut());
    else dispatch(logIn());
    return{
      pathname: '/mensajes',
      state:{
        isLogged: isLogged
      }
    }
  }
  /*{isLogged?:<Redirect to='/'/>}*/
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1>ReactJS | Imagina Formación</h1>
        </header>
        <div className="App-body">
          <Route exact path="/" component={Login}/>
          <ProtectedRoute exact path="/mensajes" component={Mensajes}/>
        </div>
      </div>
    </Router>
  );
}

export default App;
